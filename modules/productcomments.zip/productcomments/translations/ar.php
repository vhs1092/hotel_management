<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{productcomments}prestashop>default_dfbe69c6d9568ecb0e65e7b32ed92a3a'] = 'المنتج غير موجود';
$_MODULE['<{productcomments}prestashop>productcomments_c888438d14855d7d96a2724ee9c306bd'] = 'تم تحديث الإعدادات بنجاح';
$_MODULE['<{productcomments}prestashop>productcomments_254f642527b45bc260048e30704edb39'] = 'الإعدادات';
$_MODULE['<{productcomments}prestashop>productcomments_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'مفعل';
$_MODULE['<{productcomments}prestashop>productcomments_b9f5c797ebbf55adccdd8539a65a0241'] = 'غير مفعل';
$_MODULE['<{productcomments}prestashop>productcomments_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{productcomments}prestashop>productcomments_b718adec73e04ce3ec720dd11a06a308'] = 'الرقم التعريفي';
$_MODULE['<{productcomments}prestashop>productcomments_49ee3087348e8d44e1feda1917443987'] = 'الاسم';
$_MODULE['<{productcomments}prestashop>productcomments_a1fa27779242b4902f7ae3bdd5c6d508'] = 'النوع';
$_MODULE['<{productcomments}prestashop>productcomments_ec53a8c4f07baed5d8825072c89799be'] = 'الحالة';
$_MODULE['<{productcomments}prestashop>productcomments_deb10517653c255364175796ace3553f'] = 'منتج';
$_MODULE['<{productcomments}prestashop>productcomments_91b442d385b54e1418d81adc34871053'] = 'محدد';
$_MODULE['<{productcomments}prestashop>productcomments_b56c3bda503a8dc4be356edb0cc31793'] = 'فتح الكل';
$_MODULE['<{productcomments}prestashop>productcomments_5ffd7a335dd836b3373f5ec570a58bdc'] = 'إغلاق الكل';
$_MODULE['<{productcomments}prestashop>productcomments_5e9df908eafa83cb51c0a3720e8348c7'] = 'تحديد الكل';
$_MODULE['<{productcomments}prestashop>productcomments_9747d23c8cc358c5ef78c51e59cd6817'] = 'إلغاء التحديد';
$_MODULE['<{productcomments}prestashop>productcomments_4d3d769b812b6faa6b76e1a8abaece2d'] = 'نشط';
$_MODULE['<{productcomments}prestashop>productcomments_e0aa021e21dddbd6d8cecec71e9cf564'] = 'اعتماد التخفيض';
$_MODULE['<{productcomments}prestashop>productcomments_a6105c0a611b41b08f1209506350279e'] = 'نعم';
$_MODULE['<{productcomments}prestashop>productcomments_7fa3b767c460b54a2be4d49030b349c7'] = 'لا';
$_MODULE['<{productcomments}prestashop>productcomments_70397c4b252a5168c5ec003931cea215'] = 'حقول مطلوبة';
$_MODULE['<{productcomments}prestashop>productcomments_94966d90747b97d1f0f206c98a8b1ac3'] = 'ارسل';
$_MODULE['<{productcomments}prestashop>productcomments_e81c4e4f2b7b93b481e13a8553c2ae1b'] = 'أو';
$_MODULE['<{productcomments}prestashop>productcomments_ea4788705e6873b424c65e91c2846b19'] = 'إلغاء';
$_MODULE['<{productcomments}prestashop>products-comparison_b1897515d548a960afe49ecf66a29021'] = 'متوسط';
$_MODULE['<{productcomments}prestashop>productcomments_93cba07454f06a4a960172bbd6e2a435'] = 'نعم';
$_MODULE['<{productcomments}prestashop>productcomments_bafd7322c6e97d25b6299b5d6fe8920b'] = 'لا';
$_MODULE['<{productcomments}prestashop>productcomments_a4d3b161ce1309df1c4e25df28694b7b'] = 'إعتماد';


return $_MODULE;
